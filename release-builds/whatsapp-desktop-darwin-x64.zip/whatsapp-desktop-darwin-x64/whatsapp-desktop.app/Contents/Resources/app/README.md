# whatsapp-desktop
**Unofficial** multi platform desktop client for WhatsApp.
This is a wrapper of WhatsApp web created using [electron](https://electronjs.org/) can be used under Linux, Windows and MacOS.

## Quick start
To start using the client...

## Linux
### Run
### Compile

## Windows
### Run
### Compile

## Mac OS
### Run
### Compile
